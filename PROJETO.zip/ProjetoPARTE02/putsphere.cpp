#include "putsphere.h"

PutSphere::PutSphere(int icenter, int jcenter, int kcenter, int _r,float mr,float mg,float mb,float ma)
{
    r = mr; g = mg; b = mb; alpha = ma;
    xcenter = icenter; ycenter = jcenter; zcenter = kcenter; radius = _r;
}

void PutSphere::draw(Sculptor &s)
{
    for(int i =xcenter-radius; i<=xcenter+radius; i++){
            for(int j =ycenter-radius; j<=ycenter+radius; j++){
                for(int k =zcenter-radius; k<=zcenter+radius; k++){
                    if(((i - xcenter)*(i - xcenter) + (j - ycenter)*(j - ycenter) + (k - zcenter)*(k - zcenter)) <= radius*radius){
                        s.setColor(r,g,b,alpha);
                        s.putVoxel(i,j,k);
                    }
                }
            }
        }
}
