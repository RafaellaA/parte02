#ifndef PUTELLIPSOID_H
#define PUTELLIPSOID_H
#include "figurageometrica.h"

class PutEllipsoid:public FiguraGeometrica
{
private:

    int xcenter,ycenter,zcenter,rx,ry,rz;
    float r,g,b,alpha;
public:
    PutEllipsoid(int icenter,int jcenter, int kcenter, int _rx,int _ry, int _rz,float mr,float mg,float mb,float ma);
    void draw(Sculptor &s);
};

#endif // PUTELLIPSOID_H

