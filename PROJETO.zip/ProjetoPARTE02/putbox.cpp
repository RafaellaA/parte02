#include "putbox.h"
#include <iostream>

PutBox::PutBox(int i0, int i1, int j0, int j1, int k0, int k1, float mr, float mg, float mb, float ma)
{
    x0 = i0;
       x1 = i1;
       y0 = j0;
       y1 = j1;
       z0 = k0;
       z1 = k1;
       r = mr;
       g = mg;
       b = mb;
       alpha = ma;

}

void PutBox::draw(Sculptor &s)
{

    for(int x=x0;x<x1;x++){
        for(int y=y0;y<y1;y++){
            for(int z=z0;z<z1;z++){
                s.setColor(r,g,b,alpha);
                s.putVoxel(x,y,z);
            }
        }
    }
}
