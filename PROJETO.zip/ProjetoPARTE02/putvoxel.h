#ifndef PUTVOXEL_H
#define PUTVOXEL_H
#include "figurageometrica.h"

class PutVoxel:public FiguraGeometrica
{
private:
    float r,g,b,alpha;
    int x,y,z;


public:
    PutVoxel(int mx,int my,int mz, float mr,float mg,float mb, float ma);
    void draw(Sculptor &s);
};

#endif // PUTVOXEL_H
