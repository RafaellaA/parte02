#include "putellipsoid.h"
#include <cmath>


PutEllipsoid::PutEllipsoid(int icenter, int jcenter, int kcenter, int _rx, int _ry, int _rz,float mr,float mg,float mb,float ma)
{   xcenter = icenter; ycenter = jcenter; zcenter = kcenter;
    rx = _rx; ry = _ry; rz = _rz;
    r = mr; g = mg; b = mb; alpha = ma;
}

void PutEllipsoid::draw(Sculptor &s)
{
    for(int i =xcenter-rx; i<=xcenter+rx; i++){
            for(int j =ycenter-ry; j<=ycenter+rx; j++){
                for(int k =zcenter-rx; k<=zcenter+rx; k++){
                    if(((pow((i - xcenter),2)/(float)pow(rx,2) + (pow((j - ycenter),2))/(float)pow(ry,2) + (pow((k - zcenter),2))/(float)pow(rz,2)) <= 1)){
                        s.setColor(r,g,b,alpha);
                        s.putVoxel(i,j,k);
                    }
                }
            }
        }

}

