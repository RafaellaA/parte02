#ifndef PUTSPHERE_H
#define PUTSPHERE_H
#include "figurageometrica.h"

class PutSphere:public FiguraGeometrica
{
private:

    float r,g,b,alpha;
    int xcenter,ycenter,zcenter,radius;
public:
    PutSphere(int icenter,int jcenter,int kcenter,int _r,float mr,float mg,float mb,float ma);
    void draw(Sculptor &s);
};

#endif // PUTSPHERE_H

